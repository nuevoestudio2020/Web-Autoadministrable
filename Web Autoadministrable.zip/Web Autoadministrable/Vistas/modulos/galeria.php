<div class="banner-bottom py-5" id="gallery">
		<div class="container py-md-3">
			 <div class="w3-head-all mb-3">
		         <h3>Galeria</h3>
		       </div>
			<div class="row inner-sec">

				<?php

				$galeria = new GaleriaC();
				$galeria -> MostrarGaleriaC();

				?>
				
			</div>
		</div>
	</div>