<div class="welcome py-5" id="about"> 
	<div class="container py-md-3">
		<div class="row">
		<div class="col-lg-6 welcome-w3lright">
			<div class="video-grid-single-page-agileits">

				<?php

				$nosotros = new NosotrosC();
				$nosotros -> MostrarNosotrosC();

				?>
			 
		</div>
			</div>
		<div class="clearfix"> </div>
	</div> 
</div>