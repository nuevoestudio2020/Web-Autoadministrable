<?php

      $generales1 = new InicioC();
      $generales1 -> VerGenerales1C();

?>