<?php

      $generales2 = new InicioC();
      $generales2 -> VerGenerales2C();

?>