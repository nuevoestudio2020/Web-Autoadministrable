<div class="slider">
	<div class="callbacks_container">
			<ul class="rslides callbacks callbacks1" id="slider4">
				<?php

				$slide = new SlideC();
				$slide -> MostrarSlideC();

				?>
				
				<div class="clearfix"></div>
			
			</ul>
	</div>
