<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

     <ul class="sidebar-menu" data-widget="tree">

      <li>
        <a href="inicio">
          <i class="fa fa-home"></i>
          <span>Inicio</span>
        </a>
      </li>

      <li>
        <a href="slide">
          <i class="fa fa-image"></i>
          <span>Slide</span>
        </a>
      </li>

      <li>
        <a href="nosotros">
          <i class="fa fa-book"></i>
          <span>Nosotros</span>
        </a>
      </li>

      <li>
        <a href="servicios">
          <i class="fa fa-check-circle"></i>
          <span>Servicios</span>
        </a>
      </li>

      <li>
        <a href="galeria">
          <i class="fa fa-camera"></i>
          <span>Galería</span>
        </a>
      </li>

      </li>

      <li>
        <a href="mensajes">
          <i class="fa fa-envelope"></i>
          <span>Mensajes</span>
        </a>
      </li>

      <li>
        <a href="suscriptores">
          <i class="fa fa-paper-plane"></i>
          <span>Suscriptores</span>
        </a>
      </li>

      <li>
        <a href="usuarios">
          <i class="fa fa-users"></i>
          <span>Usuarios</span>
        </a>
      </li>

     </ul>

    </section>
    <!-- /.sidebar -->
  </aside>
