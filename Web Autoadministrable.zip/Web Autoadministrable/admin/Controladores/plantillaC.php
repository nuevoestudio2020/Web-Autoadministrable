<?php

class PlantillaC{

	public function LlamarPlantilla(){

		include "Vistas/plantilla.php";

	}

}
